#include <Arduino.h>

class MIDI_CALC
{
public:

	void get_Scale(int key, int scale_Type, int note_Out_Buff[6][7]);







};