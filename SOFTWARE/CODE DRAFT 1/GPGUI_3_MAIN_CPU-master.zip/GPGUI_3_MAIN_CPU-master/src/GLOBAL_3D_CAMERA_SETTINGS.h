//CAMERA USES RIGHT HAND XYZ

#define global_Far_Plane     130;
#define global_Near_Plane      1;
#define global_FOV             60;