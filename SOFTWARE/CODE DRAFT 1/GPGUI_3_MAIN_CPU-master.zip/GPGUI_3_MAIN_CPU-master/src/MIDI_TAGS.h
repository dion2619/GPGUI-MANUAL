
//CONTROL CHANGE CC MESSAGES
#define CH1_CC_STATUS  176
#define CH2_CC_STATUS  177
#define CH3_CC_STATUS  178
#define CH4_CC_STATUS  179
#define CH5_CC_STATUS  180
#define CH6_CC_STATUS  181
#define CH7_CC_STATUS  182
#define CH8_CC_STATUS  183
#define CH9_CC_STATUS  184
#define CH10_CC_STATUS 185
#define CH11_CC_STATUS 186
#define CH12_CC_STATUS 187
#define CH13_CC_STATUS 188
#define CH14_CC_STATUS 189
#define CH15_CC_STATUS 190
#define CH16_CC_STATUS 191

//CC DATA 1 TAGS
#define ALL_SOUND_OFF 120
#define VOLUME        7







//NOTE ONE OFF MESSAGES
#define CH1_NOTE_OFF    128
#define CH2_NOTE_OFF    129
#define CH3_NOTE_OFF    130
#define CH4_NOTE_OFF    131
#define CH5_NOTE_OFF    132
#define CH6_NOTE_OFF    133
#define CH7_NOTE_OFF    134
#define CH8_NOTE_OFF    135
#define CH9_NOTE_OFF    136
#define CH10_NOTE_OFF   137
#define CH11_NOTE_OFF   138
#define CH12_NOTE_OFF   139
#define CH13_NOTE_OFF   140
#define CH14_NOTE_OFF   141
#define CH15_NOTE_OFF   142
#define CH16_NOTE_OFF   143




#define CH1_NOTE_ON    144
#define CH2_NOTE_ON    145
#define CH3_NOTE_ON    146
#define CH4_NOTE_ON    147
#define CH5_NOTE_ON    148
#define CH6_NOTE_ON    149
#define CH7_NOTE_ON    150
#define CH8_NOTE_ON    151
#define CH9_NOTE_ON    152
#define CH10_NOTE_ON   153
#define CH11_NOTE_ON   154
#define CH12_NOTE_ON   155
#define CH13_NOTE_ON   156
#define CH14_NOTE_ON   157
#define CH15_NOTE_ON   158
#define CH16_NOTE_ON   159