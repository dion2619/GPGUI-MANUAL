

#define get_Points_Isometric_Tile_Ortho_Debug          false//
#define draw_Isometric_Ortho_Tile_Debug                false//
#define DDA_Line_Debug                                 false//
#define rotate_Point_Debug                             false//
#define angled_Point_Step_Debug                        false//
#define sine_Jump_Debug                                false//
#define draw_Isometric_Grid_From_Buffer_10x10_Debug    false//
#define triangle_Debug                                 false//
#define PS2_Keyboard_Debug                             false//
#define draw_Perspective_Grid_Debug					   false//
#define draw_Perspective_Grid_With_Back_Plane_Debug    false//
#define vertex_Transform_Debug                         false//