#define i2cAddress_System_A 1
#define i2cAddress_Soundcard 12




#define mouse_Com_Port 0

