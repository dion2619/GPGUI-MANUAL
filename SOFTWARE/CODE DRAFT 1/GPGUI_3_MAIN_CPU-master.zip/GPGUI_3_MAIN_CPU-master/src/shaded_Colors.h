
#define red_s 1
#define blue_s 2
#define yellow_s 3
#define green_s 4
#define purple_s 5
#define grey_s 6
#define orand_s 7






struct shaded_Colors
{

    int shaded_Color[7][4] =
    {
        {1,2,2,3},//red
        {16,32,36,40},//blue
        {11,10,15,31},//yellow
        {4,8,12,12},//green
        {17,35,35,38},//purple
        {21,21,43,47},//grey
        {6,6,7,7}//orange
    };


};