#define SAM_Reset_Pin PA0


#define DAC_GAIN_P6_DB 0
#define DAC_GAIN_P5_DB 1
#define DAC_GAIN_P4_DB 2
#define DAC_GAIN_P3_DB 3
#define DAC_GAIN_P2_DB 4
#define DAC_GAIN_P1_DB 5
#define DAC_GAIN_0_DB  6
#define DAC_GAIN_N1_DB 7
#define DAC_GAIN_N2_DB 8
#define DAC_GAIN_N3_DB 9
#define DAC_GAIN_N4_DB 10
#define DAC_GAIN_N5_DB 11
#define DAC_GAIN_N6_DB 12
#define DAC_GAIN_N7_DB 13
#define DAC_GAIN_N8_DB 14
#define DAC_GAIN_N9_DB 15
#define DAC_GAIN_N38DB 16
#define DAC_GAIN_N39DB 17
#define DAC_GAIN_N40DB 18
#define DAC_GAIN_N43P5_DB 19
#define DAC_GAIN_N58P51_DB 20

